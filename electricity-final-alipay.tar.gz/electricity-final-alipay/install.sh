#!/bin/sh
set -eu
APP=${1:-/root/electricity-log}
HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
command -v node >/dev/null || { echo '需要 Node.js'; exit 1; }
node "$HERE/install.cjs" "$APP" "$HERE"
