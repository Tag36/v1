# 电量管理 UI + 支付宝充值入口

基于正常原版，或 apple-safe-ui 轻量补丁版本安装。不适用于旧异常 electricity-apple-patch。

## 安装
```sh
cd /root
tar -xzf electricity-final-alipay.tar.gz
sh /root/electricity-final-alipay/install.sh /root/electricity-log
```
不需要 npm install，不重启 PM2。保存输出的恢复命令，刷新浏览器。

## 范围
保留原首页全部数据元素和所有 JS 数据脚本、后端、数据库。增加覆盖样式与静态支付宝链接。隐藏地址电表号、重复月份框、昨日快捷按钮；保留右上角切换、同步日期/月按钮。标题为电量管理。

电费充值使用支付宝 PNG 图标，通过 alipays://platformapi/startapp?appId=20000067&url=... 尝试在支付宝内打开 http://www.wap.cnyiot.com/nat/pay.aspx?mid=19503352437 。没有普通浏览器自动回退，不自动提交金额或付款。

这是充值页面唤起链接，不是已验证的支付 API 集成。尚未完成用户真机支付宝跳转及付款验证；支付宝版本、安全策略或 HTTP 页面限制可能阻止打开。如未跳转，不要重复付款，检查是否安装支付宝、是否允许唤起，或使用辰域官方支持的支付方式。辰域页面显示最低充值 100 元，实际以页面为准。

支付宝登录或支付密码仅在支付宝可信原生页面输入，不在 HTTP 网页输入。首页隐藏电表号只是视觉隐藏；专属充值链接仍含电表号，不能视作权限控制。

本包不包含之前危险的 MutationObserver，也不修改单价格式。充值入口不决定付款是否成功，结果以辰域与支付宝记录为准。
