# 电量管理 Apple UI 补丁

适用于当前 `/root/electricity-log` 正式版。

## 保留的功能

- 当前电量立即采集
- 昨日数据查看
- 指定日期同步
- 指定月份及上月历史同步
- 每日热力图与详情
- 7 天／30 天趋势
- 分时用电
- 辰域连接与自动采集
- 原数据库、环境变量和后端接口

## 安装

将压缩包上传到 `/root` 后：

```sh
cd /root
tar -xzf electricity-apple-patch.tar.gz
sh /root/electricity-apple-patch/install.sh /root/electricity-log
```

安装脚本会输出备份目录与恢复命令。无需重新安装依赖，也无需重启 PM2。

## 电费充值

按钮打开金额选择面板，再尝试唤起支付宝生活缴费。支付宝通常不允许网页自动带入电表号和金额，最终户号、金额及付款需在支付宝中确认。本项目不经手资金。
