#!/bin/sh
set -eu
APP="${1:-/root/electricity-log}"
HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
PUB="$APP/public"
for f in index.html js/app.js js/history.js js/chart.js js/calendar.js; do
  test -f "$PUB/$f" || { echo "缺少 $PUB/$f，补丁未安装" >&2; exit 1; }
done
STAMP=$(date +%Y%m%d-%H%M%S)
BACKUP="$APP/apple-ui-backup-$STAMP"
mkdir -m 700 "$BACKUP"
cp -R "$PUB" "$BACKUP/public"
mkdir -p "$PUB/css" "$PUB/js" "$PUB/img"
cp "$HERE/files/index.html" "$PUB/index.html"
cp "$HERE/files/css/apple.css" "$PUB/css/apple.css"
cp "$HERE/files/js/apple-ui.js" "$PUB/js/apple-ui.js"
cp "$HERE/files/img/alipay.png" "$PUB/img/alipay.png"
cat > "$BACKUP/restore.sh" <<EOF
#!/bin/sh
set -eu
rm -rf "$PUB"
cp -R "$BACKUP/public" "$PUB"
echo "已恢复原界面"
EOF
chmod 700 "$BACKUP/restore.sh"
echo "Apple UI 补丁安装完成"
echo "备份目录: $BACKUP"
echo "恢复命令: sh $BACKUP/restore.sh"
echo "无需重启 PM2，请刷新浏览器"
