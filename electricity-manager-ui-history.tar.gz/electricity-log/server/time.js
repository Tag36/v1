const { DateTime } = require('luxon');

const ZONE = process.env.APP_TIMEZONE || 'Asia/Shanghai';

function nowUTCISO() {
  return DateTime.utc().toISO();
}

function nowShanghai() {
  return DateTime.now().setZone(ZONE);
}

function todayShanghai() {
  return nowShanghai().toFormat('yyyy-MM-dd');
}

function yesterdayShanghai() {
  return nowShanghai().minus({ days: 1 }).toFormat('yyyy-MM-dd');
}

function shanghaiDate(year, month, day = 1) {
  return DateTime.fromObject(
    { year: Number(year), month: Number(month), day: Number(day) },
    { zone: ZONE }
  );
}

function parseCnyiotDateTime(value) {
  if (!value) return null;

  const formats = [
    'MM/dd/yyyy HH:mm:ss',
    'yyyy-MM-dd HH:mm:ss',
    'yyyy-MM-dd  HH:mm:ss'
  ];

  for (const fmt of formats) {
    const dt = DateTime.fromFormat(String(value).trim(), fmt, { zone: ZONE });
    if (dt.isValid) return dt;
  }

  const iso = DateTime.fromISO(String(value), { setZone: true });
  return iso.isValid ? iso.setZone(ZONE) : null;
}

module.exports = {
  ZONE,
  nowUTCISO,
  nowShanghai,
  todayShanghai,
  yesterdayShanghai,
  shanghaiDate,
  parseCnyiotDateTime,
};
