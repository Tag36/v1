const express = require('express');
const router = express.Router();

const cnyiot = require('../cnyiot');
const { syncOfficialHistory, collectCurrent } = require('../service');
const { todayShanghai } = require('../time');

const METER_ID = process.env.METER_ID;
const PASSWORD = process.env.CNYIOT_PASSWORD || '';

router.get('/status', (req, res) => {
  res.json({
    success: true,
    data: cnyiot.getAuthStatus(),
  });
});

router.get('/captcha', async (req, res) => {
  try {
    const captcha = await cnyiot.getCaptcha();
    res.json({
      success: true,
      data: {
        mimeType: captcha.mimeType,
        image: `data:${captcha.mimeType};base64,${captcha.base64}`,
      },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.post('/login', async (req, res) => {
  try {
    const captcha = String(req.body?.captcha || '').trim();

    if (!PASSWORD) {
      return res.status(500).json({
        success: false,
        message: '服务器未配置 CNYIOT_PASSWORD',
      });
    }

    await cnyiot.login(METER_ID, PASSWORD, captcha);

    // 登录后立即同步一次官方数据。
    await collectCurrent(METER_ID).catch(() => null);
    await syncOfficialHistory(METER_ID, todayShanghai()).catch(() => null);

    res.json({
      success: true,
      data: cnyiot.getAuthStatus(),
      message: '辰域登录成功',
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: error.message,
    });
  }
});

router.post('/logout', async (req, res) => {
  await cnyiot.logout();
  res.json({ success: true, message: '已退出辰域登录' });
});

module.exports = router;
