const express = require('express');
const router = express.Router();

const { getLatestReading } = require('../db');
const { collectData } = require('../service');

const METER_ID = process.env.METER_ID;

router.get('/current', (req, res) => {
  try {
    const reading = getLatestReading(METER_ID);

    if (!reading) {
      return res.json({
        success: false,
        message: '暂无数据，请先采集',
      });
    }

    res.json({
      success: true,
      data: {
        // 原项目字段保持不变
        meterId: reading.meter_id,
        meterName: reading.meter_name,
        remainingKwh: reading.remaining_kwh,
        remainingMoney: reading.remaining_money,
        pricePerKwh: reading.price_per_kwh,
        collectedAt: reading.collected_at,

        // V1 增强字段，仅新增，不重命名原字段
        totalKwh: reading.total_kwh,
        voltage: reading.voltage,
        currentAmp: reading.current_amp,
        powerFactor: reading.power_factor,
        powerKw: reading.power_kw,
        relayStatus: reading.relay_status,
        source: reading.source,
        deviceTime: reading.device_time,
      },
    });
  } catch (error) {
    console.error('获取当前电表数据失败:', error);
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
});

router.get('/fetch', async (req, res) => {
  try {
    const data = await collectData(METER_ID);
    res.json({
      success: true,
      data,
      message: '采集成功',
    });
  } catch (error) {
    console.error('手动采集失败:', error);
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
});

module.exports = router;
