const router = require('express').Router();
const {DateTime}=require('luxon');
const c=require('../cnyiot');
const db=require('../db');
let busy=false;
router.post('/',async(req,res)=>{
 const {date,scope}=req.body||{};
 const dt=typeof date==='string'?DateTime.fromISO(date,{zone:'Asia/Shanghai'}):null;
 if(!dt?.isValid||dt.toFormat('yyyy-MM-dd')!==date||date>DateTime.now().setZone('Asia/Shanghai').toFormat('yyyy-MM-dd')||!['month','day'].includes(scope))return res.status(400).json({success:false,message:'请选择有效的历史日期与同步类型'});
 if(!c.getAuthStatus().authenticated)return res.status(401).json({success:false,message:'请先连接辰域并输入验证码；本地历史仍可查看'});
 if(busy)return res.status(409).json({success:false,message:'历史同步正在执行，请稍后再试'});
 busy=true;
 try{
 const meterId=process.env.METER_ID;
 const price=db.getLatestReading(meterId)?.price_per_kwh;
 const rows=scope==='month'?await c.getDailyUsage(meterId,date):await c.getHourlyUsage(meterId,date);
 const today=DateTime.now().setZone('Asia/Shanghai').toFormat('yyyy-MM-dd');
 const valid=rows.filter(r=>Number.isFinite(r.usageKwh)&&r.usageKwh>=0&&(scope==='month'?r.date<=today&&r.date.startsWith(date.slice(0,7)):Number.isInteger(r.hour)&&r.hour>=0&&r.hour<24));
 db.getDB().transaction(()=>{for(const r of valid){const data={meterId,date:r.date||date,hour:r.hour,startKwh:null,endKwh:null,usageKwh:r.usageKwh,costMoney:Number.isFinite(price)?Math.round(r.usageKwh*price*100)/100:null,isRecharge:false,source:'cnyiot-official'};if(scope==='month')db.upsertDailyUsage(data);else db.upsertHourlyUsage(data);}})();
 res.json({success:true,data:{count:valid.length,date,scope},message:valid.length?`已保存 ${valid.length} 条官方数据`:'官方未返回有效数据，已有本地记录未改动'});
 }catch(e){res.status(502).json({success:false,message:e.message});}finally{busy=false;}
});
module.exports=router;
