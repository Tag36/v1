const express = require('express');
const router = express.Router();

const {
  getDailyUsageByDateRange,
  getDailyUsageByMonth,
  getRecentDailyUsage,
  getHourlyUsage,
  getMonthSummary,
} = require('../db');
const { todayShanghai } = require('../time');

const METER_ID = process.env.METER_ID;

function mapDaily(r) {
  return {
    // 原项目字段保持不变
    date: r.date,
    startKwh: r.start_kwh,
    endKwh: r.end_kwh,
    usageKwh: r.usage_kwh,
    costMoney: r.cost_money,
    isRecharge: r.is_recharge === 1,

    // 增强字段
    source: r.source,
  };
}

router.get('/daily', (req, res) => {
  try {
    const { start, end } = req.query;

    if (!start || !end) {
      return res.status(400).json({
        success: false,
        message: '请提供 start 和 end 参数',
      });
    }

    res.json({
      success: true,
      data: getDailyUsageByDateRange(METER_ID, start, end).map(mapDaily),
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.get('/recent', (req, res) => {
  try {
    const days = Math.max(1, Math.min(365, Number.parseInt(req.query.days, 10) || 7));
    res.json({
      success: true,
      data: getRecentDailyUsage(METER_ID, days).map(mapDaily),
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.get('/month', (req, res) => {
  try {
    let { year, month } = req.query;

    if (!year || !month) {
      const [y, m] = todayShanghai().split('-').map(Number);
      year = y;
      month = m;
    }

    year = Number.parseInt(year, 10);
    month = Number.parseInt(month, 10);

    const records = getDailyUsageByMonth(METER_ID, year, month);
    const summary = getMonthSummary(METER_ID, year, month);

    res.json({
      success: true,
      // 原项目 data + month 保持
      data: records.map(mapDaily),
      month: `${year}-${String(month).padStart(2, '0')}`,

      // 新增后端汇总，前端不自行累加
      summary: {
        totalUsage: summary.totalUsage,
        totalCost: summary.totalCost,
        avgDailyUsage: summary.avgDailyUsage,
        avgDailyCost: summary.avgDailyCost,
        daysWithData: summary.daysWithData,
        todayVsYesterdayPercent: summary.todayVsYesterdayPercent,
        source: summary.source,
      },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.get('/hourly', (req, res) => {
  try {
    const { date } = req.query;

    if (!date) {
      return res.status(400).json({
        success: false,
        message: '请提供 date 参数 (YYYY-MM-DD)',
      });
    }

    const rows = getHourlyUsage(METER_ID, date);

    const hourlyData = rows.map(r => ({
      // 与原项目字段一致
      hour: Number(r.hour),
      hourLabel: `${String(r.hour).padStart(2, '0')}:00`,
      usageKwh: r.usage_kwh,
      costMoney: r.cost_money,
      startKwh: r.start_kwh ?? null,
      endKwh: r.end_kwh ?? null,
      isRecharge: r.is_recharge === 1,
      hasData: r.usage_kwh !== null && r.usage_kwh !== undefined,

      // 增强字段
      source: r.source,
    }));

    const available = hourlyData.filter(h => h.hasData);
    const totalUsage = available.reduce((sum, h) => sum + Number(h.usageKwh || 0), 0);
    const totalCost = available.reduce((sum, h) => sum + Number(h.costMoney || 0), 0);

    let collectionPeriod = null;
    if (available.length) {
      const first = available[0].hourLabel;
      const lastHour = available[available.length - 1].hour;
      collectionPeriod = `${first} - ${String((lastHour + 1) % 24).padStart(2, '0')}:00`;
    }

    res.json({
      success: true,
      data: hourlyData,
      summary: {
        date,
        totalUsage: Math.round(totalUsage * 100) / 100,
        totalCost: Math.round(totalCost * 100) / 100,
        hoursWithData: available.length,
        hasRecharge: hourlyData.some(h => h.isRecharge),
        collectionPeriod,
        source: available[0]?.source || null,
      },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

module.exports = router;
