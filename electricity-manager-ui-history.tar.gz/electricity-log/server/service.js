const { DateTime } = require('luxon');
const { fetchPublicMeterData } = require('./scraper');
const cnyiot = require('./cnyiot');
const {
  insertReading,
  getLatestReading,
  upsertDailyUsage,
  upsertHourlyUsage,
  upsertMonthlyUsage,
  calculateAndUpdateDailyUsage,
} = require('./db');
const {
  nowUTCISO,
  nowShanghai,
  todayShanghai,
  yesterdayShanghai,
  ZONE,
} = require('./time');

const DEFAULT_PRICE = Number(process.env.DEFAULT_PRICE) || 0.8;

function priceFor(meterId, officialPrice, publicPrice) {
  if (Number(officialPrice) > 0) return Number(officialPrice);
  if (Number(publicPrice) > 0) return Number(publicPrice);
  const latest = getLatestReading(meterId);
  if (Number(latest?.price_per_kwh) > 0) return Number(latest.price_per_kwh);
  return DEFAULT_PRICE;
}

async function collectCurrent(meterId) {
  let publicData = null;
  let officialOverview = null;
  let instant = null;

  try {
    publicData = await fetchPublicMeterData(meterId);
  } catch (error) {
    console.warn('充值页采集失败:', error.message);
  }

  if (cnyiot.getAuthStatus().authenticated) {
    try {
      [officialOverview, instant] = await Promise.all([
        cnyiot.getMeterOverview(meterId),
        cnyiot.readInstant(meterId),
      ]);
    } catch (error) {
      console.warn('辰域官方实时接口采集失败:', error.message);
    }
  }

  if (!publicData && !officialOverview && !instant) {
    throw new Error('当前电表数据采集失败');
  }

  const meterName =
    officialOverview?.meterName ||
    publicData?.meterName ||
    '未知';

  const remainingKwh =
    numberOrNull(instant?.ekwh) ??
    numberOrNull(officialOverview?.remainingKwh) ??
    numberOrNull(publicData?.remainingKwh) ??
    0;

  const price = priceFor(
    meterId,
    officialOverview?.pricePerKwh,
    publicData?.pricePerKwh
  );

  // 剩余金额优先使用公开充值页，避免误判辰域内部缩写字段。
  const remainingMoney =
    numberOrNull(publicData?.remainingMoney) ??
    Math.round(remainingKwh * price * 100) / 100;

  const voltage =
    numberOrNull(instant?.otherParam_1p?.vol) ??
    numberOrNull(officialOverview?.voltage);

  const currentAmp =
    numberOrNull(instant?.otherParam_1p?.cur) ??
    numberOrNull(officialOverview?.currentAmp);

  const powerFactor =
    numberOrNull(instant?.otherParam_1p?.pf) ??
    numberOrNull(officialOverview?.powerFactor);

  const powerKw =
    voltage !== null && currentAmp !== null && powerFactor !== null
      ? Math.round((voltage * currentAmp * powerFactor / 1000) * 1000) / 1000
      : null;

  const data = {
    meterId: String(meterId),
    meterName,
    remainingKwh,
    remainingMoney,
    pricePerKwh: price,
    totalKwh:
      numberOrNull(instant?.tkwh) ??
      numberOrNull(officialOverview?.totalKwh),
    voltage,
    currentAmp,
    powerFactor,
    powerKw,
    relayStatus:
      instant?.relay !== undefined
        ? Number(instant.relay)
        : officialOverview?.relayStatus ?? null,
    deviceTime:
      instant?.datetime ||
      officialOverview?.deviceTime ||
      null,
    source:
      instant || officialOverview
        ? 'cnyiot-official'
        : 'public-pay',
    collectedAt: nowUTCISO(),
  };

  insertReading(data);
  return data;
}

async function syncOfficialHistory(meterId, date = todayShanghai()) {
  if (!cnyiot.getAuthStatus().authenticated) {
    return { synced: false, reason: 'auth-required' };
  }

  const dt = DateTime.fromFormat(date, 'yyyy-MM-dd', { zone: ZONE });
  if (!dt.isValid) throw new Error('日期格式无效');

  const latest = getLatestReading(meterId);
  const price = Number(latest?.price_per_kwh) || DEFAULT_PRICE;

  const [hourly, daily, monthly] = await Promise.all([
    cnyiot.getHourlyUsage(meterId, date),
    cnyiot.getDailyUsage(meterId, date),
    cnyiot.getMonthlyUsage(meterId, date),
  ]);

  for (const row of hourly) {
    upsertHourlyUsage({
      meterId,
      date,
      hour: row.hour,
      usageKwh: row.usageKwh,
      costMoney:
        row.usageKwh === null ? null : round2(row.usageKwh * price),
      isRecharge: false,
      source: 'cnyiot-official',
    });
  }

  for (const row of daily) {
    if (row.usageKwh === null) continue;
    upsertDailyUsage({
      meterId,
      date: row.date,
      startKwh: null,
      endKwh: null,
      usageKwh: row.usageKwh,
      costMoney: round2(row.usageKwh * price),
      isRecharge: false,
      source: 'cnyiot-official',
    });
  }

  for (const row of monthly) {
    if (row.usageKwh === null) continue;
    upsertMonthlyUsage({
      meterId,
      year: row.year,
      month: row.month,
      usageKwh: row.usageKwh,
      costMoney: round2(row.usageKwh * price),
      source: 'cnyiot-official',
    });
  }

  return {
    synced: true,
    date,
    hourlyCount: hourly.filter(r => r.usageKwh !== null).length,
    dailyCount: daily.filter(r => r.usageKwh !== null).length,
    monthlyCount: monthly.filter(r => r.usageKwh !== null).length,
  };
}

async function collectData(meterId) {
  console.log(`[${nowShanghai().toFormat('yyyy-MM-dd HH:mm:ss')}] 正在采集 ${meterId}`);

  const current = await collectCurrent(meterId);

  let official = null;
  try {
    official = await syncOfficialHistory(meterId, todayShanghai());
  } catch (error) {
    console.warn('官方历史数据同步失败:', error.message);
  }

  if (!official?.synced) {
    calculateAndUpdateDailyUsage(meterId, todayShanghai());
    calculateAndUpdateDailyUsage(meterId, yesterdayShanghai());
  }

  return current;
}

function numberOrNull(value) {
  if (value === null || value === undefined || value === '') return null;
  const n = Number(value);
  return Number.isFinite(n) ? n : null;
}

function round2(value) {
  return Math.round(Number(value) * 100) / 100;
}

module.exports = {
  collectCurrent,
  syncOfficialHistory,
  collectData,
};
