const axios = require('axios');
const cheerio = require('cheerio');
const BASE_URL = process.env.CNYIOT_URL || 'https://www.wap.cnyiot.com/nat/pay.aspx';

function numberFrom(text) {
  const match = String(text || '').replace(/,/g, '').match(/-?\d+(?:\.\d+)?/);
  return match ? Number(match[0]) : null;
}
function valueNearLabel($, keyword) {
  let found = null;
  $('body *').each((_, el) => {
    if (found !== null) return;
    const own = $(el).clone().children().remove().end().text().trim();
    if (own.includes(keyword)) {
      const text = $(el).parent().text().replace(own, '');
      found = numberFrom(text);
    }
  });
  return found;
}
function parseMeterHtml(html, requestedId) {
  const $ = cheerio.load(html);
  const body = $('body').text().replace(/\s+/g, ' ');
  const byText = key => numberFrom(body.match(new RegExp(`${key}[^0-9-]*(-?\\d+(?:\\.\\d+)?)`))?.[1]);
  const remainingKwh = valueNearLabel($, '剩余电量') ?? byText('剩余电量');
  const remainingMoney = valueNearLabel($, '剩余金额') ?? byText('剩余金额');
  const pricePerKwh = valueNearLabel($, '综合费用') ?? valueNearLabel($, '电价') ?? byText('综合费用');
  if (![remainingKwh, remainingMoney, pricePerKwh].every(Number.isFinite)) {
    throw new Error('辰域页面结构变化，未能解析电量、余额或电价');
  }
  return {
    meterId: $('#metid').text().trim() || requestedId,
    meterName: $('label').first().text().trim() || '辰域智能电表',
    remainingKwh, remainingMoney, pricePerKwh,
    collectedAt: new Date().toISOString(),
  };
}
async function fetchPublicMeterData(meterId) {
  const response = await axios.get(`${BASE_URL}?mid=${encodeURIComponent(meterId)}`, {
    headers: { 'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 Mobile/15E148',
      Accept: 'text/html,application/xhtml+xml', 'Accept-Language': 'zh-CN,zh;q=0.9' },
    timeout: 15000, responseType: 'text', validateStatus: s => s >= 200 && s < 400,
  });
  return parseMeterHtml(response.data, meterId);
}
module.exports = { fetchPublicMeterData, fetchMeterData: fetchPublicMeterData, parseMeterHtml };
