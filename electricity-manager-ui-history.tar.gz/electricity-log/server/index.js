require('dotenv').config();

const express = require('express');
const cors = require('cors');
const path = require('path');

const { initDB } = require('./db');
const { startScheduler, getSchedulerStatus } = require('./scheduler');
const { collectData } = require('./service');
const cnyiot = require('./cnyiot');

const meterRoutes = require('./routes/meter');
const recordsRoutes = require('./routes/records');
const authRoutes = require('./routes/auth');

const METER_ID = process.env.METER_ID;
const PORT = Number.parseInt(process.env.PORT, 10) || 3000;
const CRON_SCHEDULE = process.env.CRON_SCHEDULE || '0 * * * *';

if (!METER_ID) {
  throw new Error('缺少 METER_ID，请创建 .env');
}

process.env.TZ = process.env.TZ || 'Asia/Shanghai';

const app = express();

initDB();

app.disable('x-powered-by');
app.use(cors());
app.use(express.json({ limit: '256kb' }));
app.use(express.static(path.join(__dirname, '..', 'public')));

app.use('/api/meter', meterRoutes);
app.use('/api/records', recordsRoutes);
app.use('/api/auth', authRoutes);
app.use('/api/sync', require('./routes/sync'));

app.get('/api/status', (req, res) => {
  res.json({
    success: true,
    data: {
      meterId: METER_ID,
      timezone: 'Asia/Shanghai',
      scheduler: getSchedulerStatus(),
      cnyiot: cnyiot.getAuthStatus(),
    },
  });
});

app.get('/healthz', (req, res) => {
  res.type('text/plain').send('ok');
});

app.use((err, req, res, next) => {
  console.error('服务器错误:', err);
  res.status(500).json({
    success: false,
    message: err.message || '服务器内部错误',
  });
});

app.listen(PORT, async () => {
  console.log('');
  console.log('家庭用电监控 V1 已启动');
  console.log(`电表号: ${METER_ID}`);
  console.log(`地址: http://localhost:${PORT}`);
  console.log('时区: Asia/Shanghai');
  console.log('');

  // 未登录也可先使用公开充值页采集当前数据。
  try {
    await collectData(METER_ID);
    console.log('首次采集完成');
  } catch (error) {
    console.warn('首次采集失败，将由定时任务重试:', error.message);
  }

  startScheduler(METER_ID, CRON_SCHEDULE);
});
