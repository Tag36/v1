const cron = require('node-cron');
const { collectData } = require('./service');
const { nowShanghai } = require('./time');

let scheduler = null;
let currentMeterId = null;

function startScheduler(meterId, cronExpression = '0 * * * *') {
  stopScheduler();

  currentMeterId = String(meterId);

  scheduler = cron.schedule(
    cronExpression,
    () => {
      collectData(currentMeterId).catch(error => {
        console.error(
          `[${nowShanghai().toFormat('yyyy-MM-dd HH:mm:ss')}] 定时采集失败:`,
          error.message
        );
      });
    },
    {
      timezone: 'Asia/Shanghai',
    }
  );

  console.log(`定时采集已启动: ${cronExpression} (Asia/Shanghai)`);
  return scheduler;
}

function stopScheduler() {
  if (scheduler) {
    scheduler.stop();
    scheduler.destroy?.();
    scheduler = null;
  }
}

function getSchedulerStatus() {
  return {
    isRunning: scheduler !== null,
    meterId: currentMeterId,
    timezone: 'Asia/Shanghai',
  };
}

module.exports = {
  startScheduler,
  stopScheduler,
  getSchedulerStatus,
};
