const axios = require('axios');
const { CookieJar } = require('tough-cookie');
const { wrapper } = require('axios-cookiejar-support');
const { nowShanghai } = require('./time');

const BASE_URL = process.env.CNYIOT_BASE_URL || 'https://www.zk.cnyiot.com';
const USER_AGENT =
  'Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) ' +
  'AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Mobile/15E148 Safari/604.1';

const jar = new CookieJar();

const client = wrapper(axios.create({
  baseURL: BASE_URL,
  jar,
  withCredentials: true,
  timeout: 15000,
  headers: {
    'User-Agent': USER_AGENT,
    'Accept-Language': 'zh-CN,zh-Hans;q=0.9',
  },
}));

let authenticated = false;
let lastLoginAt = null;
let sessionReady = false;

async function ensureSession() {
  if (sessionReady) return;
  await client.get('/wap/indexWeb.aspx', {
    headers: { Accept: 'text/html,application/xhtml+xml' },
  });
  sessionReady = true;
}

async function getCaptcha() {
  await ensureSession();

  const response = await client.post(
    '/wap/loginWeb.aspx?Method=getimgpsw',
    null,
    {
      headers: {
        'Content-Type': 'application/json;charset=utf-8',
        Referer: `${BASE_URL}/wap/loginWeb.aspx`,
      },
      transformResponse: [(data) => data],
    }
  );

  const base64 = String(response.data || '').trim();
  if (!base64.startsWith('/9j/') && !base64.startsWith('iVBOR')) {
    throw new Error('辰域验证码返回异常');
  }

  return {
    mimeType: base64.startsWith('/9j/') ? 'image/jpeg' : 'image/png',
    base64,
  };
}

async function login(meterId, password, captcha) {
  if (!meterId || !password || !captcha) {
    throw new Error('电表号、密码和验证码不能为空');
  }

  await ensureSession();

  const response = await client.post(
    '/wap/loginWeb.aspx?Method=login',
    {
      id: String(meterId),
      psw: String(password),
      lang: 'zh-CN',
      imgyzm: String(captcha).trim(),
    },
    {
      headers: {
        'Content-Type': 'application/json;charset=utf-8',
        Referer: `${BASE_URL}/wap/loginWeb.aspx`,
      },
    }
  );

  if (response.data?.result !== 'ok') {
    authenticated = false;
    throw new Error(response.data?.value || response.data?.msg || '辰域登录失败');
  }

  authenticated = true;
  lastLoginAt = new Date().toISOString();
  return true;
}

async function logout() {
  try {
    await client.post(
      '/wap/my.aspx?Method=logout',
      "{'t':3}",
      {
        headers: {
          'Content-Type': 'application/json;charset=utf-8',
          Referer: `${BASE_URL}/wap/my.aspx`,
        },
      }
    );
  } finally {
    authenticated = false;
    sessionReady = false;
    lastLoginAt = null;
    await jar.removeAllCookies();
  }
}

function assertAuthenticated() {
  if (!authenticated) {
    const err = new Error('辰域未登录');
    err.code = 'CNYIOT_AUTH_REQUIRED';
    throw err;
  }
}

function looksLikeAuthFailure(response) {
  const data = response?.data;
  if (typeof data === 'string') {
    return data.includes('登录异常') || data.includes('loginWeb.aspx');
  }
  return data?.result === 'login' || data?.result === 'nologin';
}

async function officialPost(path, body, referer) {
  assertAuthenticated();

  const response = await client.post(path, body, {
    headers: {
      'Content-Type': 'application/json;charset=utf-8',
      Referer: `${BASE_URL}${referer}`,
    },
  });

  if (looksLikeAuthFailure(response)) {
    authenticated = false;
    const err = new Error('辰域登录已失效');
    err.code = 'CNYIOT_AUTH_REQUIRED';
    throw err;
  }

  return response.data;
}

async function readInstant(meterId) {
  const data = await officialPost(
    '/MManage.aspx?Method=ReadInstant',
    { metid: String(meterId) },
    `/wap/metInstant.aspx?MeterNo=${encodeURIComponent(meterId)}&Md=0`
  );

  if (data?.result !== 'ok' || !data?.value) {
    throw new Error(data?.value || '辰域实时数据返回异常');
  }

  return data.value;
}

async function listMeters() {
  const data = await officialPost(
    '/wap/listMet.aspx?Method=load',
    "{'ckv':'','model':0,'mt':1}",
    '/wap/listMet.aspx'
  );

  if (Number(data?.result) !== 200 || !Array.isArray(data?.value?.d)) {
    throw new Error('辰域电表列表返回异常');
  }

  return data.value.d;
}

async function getMeterOverview(meterId) {
  const meters = await listMeters();
  const meter = meters.find(item => String(Math.trunc(Number(item.i))) === String(meterId));
  if (!meter) throw new Error(`辰域账号中未找到电表 ${meterId}`);

  let othpa = {};
  try {
    othpa = meter.othpa ? JSON.parse(meter.othpa) : {};
  } catch (_) {
    othpa = {};
  }

  return {
    meterId: String(Math.trunc(Number(meter.i))),
    meterName: meter.n || '未知',
    remainingKwh: finite(meter.e),
    totalKwh: finite(meter.t),
    pricePerKwh: finite(meter.mpce),
    voltage: finite(othpa.vol),
    currentAmp: finite(othpa.cur),
    powerFactor: finite(othpa.pf),
    relayStatus: meter.r === undefined ? null : Number(meter.r),
    deviceTime: meter.d || null,
    raw: meter,
  };
}

async function getChart(meterId, date, mode) {
  const data = await officialPost(
    '/wap/charts.aspx?Method=getView',
    {
      datatime: `${date}  `,
      metID: Number(meterId),
      mType: '0',
      mYMD: String(mode),
    },
    `/wap/charts.aspx?MeterNo=${encodeURIComponent(meterId)}`
  );

  if (data?.result !== 'ok' || !data?.value) {
    throw new Error(data?.value || '辰域历史数据返回异常');
  }

  return data.value;
}

async function getHourlyUsage(meterId, date) {
  const value = await getChart(meterId, date, 1);
  const hours = value.xAxis_data || [];
  const series = value.series_data?.[0] || [];

  return hours.map((hour, index) => ({
    hour: Number(hour),
    usageKwh: nullableFinite(series[index]),
  }));
}

async function getDailyUsage(meterId, date) {
  const value = await getChart(meterId, date, 2);
  const days = value.xAxis_data || [];
  const series = value.series_data?.[0] || [];
  const [year, month] = String(date).slice(0, 7).split('-').map(Number);

  return days.map((day, index) => ({
    date: `${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`,
    usageKwh: nullableFinite(series[index]),
  }));
}

async function getMonthlyUsage(meterId, date) {
  const value = await getChart(meterId, date, 3);
  const months = value.xAxis_data || [];
  const series = value.series_data?.[0] || [];
  const year = Number(String(date).slice(0, 4));

  return months.map((month, index) => ({
    year,
    month: Number(month),
    usageKwh: nullableFinite(series[index]),
  }));
}

function finite(value) {
  const n = Number(value);
  return Number.isFinite(n) ? n : 0;
}

function nullableFinite(value) {
  if (value === null || value === undefined || value === '') return null;
  const n = Number(value);
  return Number.isFinite(n) ? n : null;
}

function getAuthStatus() {
  return {
    authenticated,
    lastLoginAt,
    sessionReady,
  };
}

module.exports = {
  getCaptcha,
  login,
  logout,
  getAuthStatus,
  readInstant,
  listMeters,
  getMeterOverview,
  getHourlyUsage,
  getDailyUsage,
  getMonthlyUsage,
};
