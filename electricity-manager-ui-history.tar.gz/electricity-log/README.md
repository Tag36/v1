# ⚡ Electricity Log V2

辰域智能电表数据采集与用电分析面板。V2 重新实现了统计引擎、API 和移动端界面。

## V2 修复

- 按 `Asia/Shanghai` 自然日统计，避免 UTC 日期错位。
- 以相邻两次读数作为采集区间；每小时采集一次也能得到分时用电。
- 跨午夜的第一段用电计入新的一天，不再漏算。
- 充值只排除“电量增加”的区间，充值前后的实际用电继续累计。
- 启动时自动用原始 `meter_readings` 重建每日汇总，兼容旧数据库。
- 增加 `/healthz`、采集状态、参数校验、并发采集保护和统计回归测试。

## 部署

```bash
git clone https://github.com/1300350674/electricity-log.git
cd electricity-log
cp .env.example .env
npm ci
npm test
npm start
```

Node.js 要求 18+。默认端口 `3000`，浏览器访问 `http://服务器IP:3000`。

> Node 不会自动读取 `.env`。直接部署时可通过 PM2 的 ecosystem 配置、systemd EnvironmentFile，或启动前 `set -a; . ./.env; set +a` 注入环境变量。

### PM2

```bash
set -a; . ./.env; set +a
pm2 start server/index.js --name electricity-log
pm2 save
curl http://127.0.0.1:3000/healthz
```

## 配置

| 变量 | 默认值 | 说明 |
|---|---|---|
| `METER_ID` | `19503352437` | 辰域电表号 |
| `PORT` | `3000` | 服务端口 |
| `CRON_SCHEDULE` | `0 * * * *` | 每小时采集 |
| `TIME_ZONE` | `Asia/Shanghai` | 统计时区 |
| `COLLECT_ON_START` | `true` | 启动立即采集 |
| `DB_PATH` | `data/electricity.db` | SQLite 路径 |

## API

- `GET /healthz`
- `GET /api/status`
- `GET /api/meter/current`
- `POST /api/meter/fetch`
- `GET /api/records/daily?start=YYYY-MM-DD&end=YYYY-MM-DD`
- `GET /api/records/month?year=2026&month=8`
- `GET /api/records/recent?days=7`
- `GET /api/records/hourly?date=YYYY-MM-DD`
- `POST /api/records/rebuild`

## 统计限制

充值区间内无法知道“充值量”和“实际耗电量”各是多少，因此 V2 会排除该负差值区间，并将当天标记为估算；其余区间照常累计。采集越频繁，误差越小。
