# 电费监控系统实现计划

## 一、项目概述

基于辰域智控系统（cnyiot.com）的电表数据，构建一个电费监控 Web 应用，实现：
- 实时展示剩余电量和剩余金额
- 日历视图展示每日用电量
- 电量变化趋势分析

## 二、调研结论

### 2.1 网站接口分析

| 接口/页面 | 地址 | 是否需要登录 | 用途 |
|----------|------|-------------|------|
| 充值页面 | `https://www.wap.cnyiot.com/nat/pay.aspx?mid={电表号}` | 否 | 获取实时电量、金额数据 |
| getpayfee API | `POST /nat/pay.aspx?Method=getpayfee` | 否 | 获取支付费率信息 |
| showMetStatus API | `POST /nat/pay.aspx?Method=showMetStatus` | 否 | 获取电表状态（通常为空） |
| 交易记录 | `/wap/metDeal.aspx?MeterNo={电表号}` | 是 | 历史用电记录（无法直接访问） |

### 2.2 可获取数据字段

从充值页面 HTML 中可直接解析获取：
- **表名称**：如 "桃花园F3栋801-6"
- **表号**：电表唯一标识（mid 参数）
- **剩余电量**：单位 kWh
- **剩余金额**：单位 元
- **综合费用（电价）**：单位 元/kWh
- **最小充值金额**：单位 元

### 2.3 技术限制与应对方案

**问题**：无法直接获取历史用电记录（需要登录）

**解决方案**：
1. 采用**定时采集**策略，定期抓取当前电量和金额
2. 通过对比相邻时间点的数据差值，计算每日/每小时用电量
3. 将采集数据持久化存储在本地数据库
4. 程序运行时间越长，历史数据越完整

## 三、技术选型

### 3.1 后端技术栈
- **运行时**：Node.js
- **Web 框架**：Express.js
- **数据抓取**：axios + cheerio（HTTP 请求 + HTML 解析）
- **数据库**：SQLite（轻量级，单文件存储，无需额外服务）
- **定时任务**：node-cron

### 3.2 前端技术栈
- 原生 HTML + CSS + JavaScript（无需构建工具）
- **日历组件**：FullCalendar 或简单自定义日历
- **图表库**：Chart.js（趋势图展示）

## 四、项目结构

```
electricity-log/
├── package.json
├── .gitignore
├── README.md
├── server/
│   ├── index.js              # 服务入口
│   ├── db.js                 # 数据库初始化与操作
│   ├── scraper.js            # 网页数据抓取模块
│   ├── scheduler.js          # 定时采集任务
│   └── routes/
│       ├── meter.js          # 电表数据相关 API
│       └── records.js        # 用电记录相关 API
├── public/
│   ├── index.html            # 主页面
│   ├── css/
│   │   └── style.css         # 样式文件
│   └── js/
│       ├── app.js            # 主逻辑
│       ├── calendar.js       # 日历组件
│       └── chart.js          # 图表组件
└── data/
    └── electricity.db        # SQLite 数据库文件（自动生成）
```

## 五、数据库设计

### 5.1 meter_readings 表（电量采集记录表）

| 字段 | 类型 | 说明 |
|------|------|------|
| id | INTEGER PRIMARY KEY | 自增主键 |
| meter_id | TEXT | 电表号 |
| meter_name | TEXT | 表名称 |
| remaining_kwh | REAL | 剩余电量（kWh） |
| remaining_money | REAL | 剩余金额（元） |
| price_per_kwh | REAL | 电价（元/kWh） |
| collected_at | DATETIME | 采集时间 |

### 5.2 daily_usage 表（每日用电量表，由采集数据计算生成）

| 字段 | 类型 | 说明 |
|------|------|------|
| id | INTEGER PRIMARY KEY | 自增主键 |
| meter_id | TEXT | 电表号 |
| date | DATE | 日期 |
| start_kwh | REAL | 当日起始电量 |
| end_kwh | REAL | 当日结束电量 |
| usage_kwh | REAL | 当日用电量（kWh） |
| cost_money | REAL | 当日电费（元） |
| created_at | DATETIME | 创建时间 |

## 六、功能模块与实现步骤

### 阶段一：数据采集与存储

1. **创建项目基础结构**
   - 初始化 npm 项目
   - 安装依赖：express, axios, cheerio, better-sqlite3, node-cron, cors
   - 配置 .gitignore

2. **实现网页数据抓取模块** (`server/scraper.js`)
   - 向充值页面发送 HTTP 请求
   - 使用 cheerio 解析 HTML，提取电量、金额等数据
   - 封装为 `fetchMeterData(meterId)` 函数

3. **实现数据库模块** (`server/db.js`)
   - 初始化 SQLite 数据库
   - 创建 meter_readings 表和 daily_usage 表
   - 封装数据插入、查询等操作函数

4. **实现定时采集任务** (`server/scheduler.js`)
   - 使用 node-cron 配置定时任务（建议每小时采集一次）
   - 每次采集后自动计算并更新当日用电量

### 阶段二：API 服务

5. **实现 Express 服务** (`server/index.js`)
   - 启动 HTTP 服务器
   - 配置静态文件服务（public 目录）
   - 启用 CORS
   - 启动时执行一次数据采集
   - 启动定时任务

6. **实现电表数据 API** (`server/routes/meter.js`)
   - `GET /api/meter/current` - 获取最新电表数据
   - `GET /api/meter/fetch` - 手动触发一次数据采集

7. **实现用电记录 API** (`server/routes/records.js`)
   - `GET /api/records/daily?start=&end=` - 获取指定日期范围的每日用电量
   - `GET /api/records/recent?days=` - 获取最近 N 天的用电数据
   - `GET /api/records/month?year=&month=` - 获取某月的每日用电数据

### 阶段三：前端页面

8. **创建主页面布局** (`public/index.html`)
   - 顶部：电表基本信息卡片（表名、表号、电价）
   - 中部：实时数据展示（剩余电量、剩余金额）
   - 下部：日历视图
   - 底部：趋势图表

9. **实现样式** (`public/css/style.css`)
   - 现代化卡片式设计
   - 响应式布局，适配手机和桌面
   - 日历格子的用电量颜色分级（用颜色深浅表示用量多少）

10. **实现日历组件** (`public/js/calendar.js`)
    - 月视图日历展示
    - 每一天显示当日用电量
    - 支持上一月/下一月切换
    - 点击某天查看详细数据

11. **实现图表组件** (`public/js/chart.js`)
    - 近 7 天/30 天用电量趋势图（折线图）
    - 近 7 天/30 天电费趋势图

12. **实现主逻辑** (`public/js/app.js`)
    - 页面加载时获取最新数据
    - 调用 API 获取历史数据
    - 绑定日历和图表的交互事件
    - 自动刷新机制（可选）

### 阶段四：优化与完善

13. **数据补全与校准逻辑**
    - 如果某天有多次采集，取最早和最晚的数据计算当日用量
    - 如果缺失某天的数据，用相邻日期数据进行估算（可选）
    - 处理充值导致的电量跳变（充值后电量增加，需特殊处理）

14. **配置项**
    - 电表号配置
    - 采集频率配置
    - 端口配置
    - （可选）多电表支持

## 七、关键技术点与风险处理

### 7.1 充值跳变问题

**问题**：用户充值后，剩余电量会突然增加，导致当日用电量计算为负数。

**处理方案**：
- 检测到电量增加时，标记为"充值事件"
- 当日用电量 = （充值前电量 - 当日起始电量） + （当日结束电量 - 充值后电量）
- 或者更简单：如果 end_kwh > start_kwh，则当日用电量记为 0（保守估计）
- 在界面上标注充值事件

### 7.2 数据缺失问题

**问题**：如果程序关闭或网络故障，会缺失某些时间点的数据。

**处理方案**：
- 程序启动时自动补采一次
- 每日用电量使用当天最后一条和前一天最后一条数据计算
- 数据缺失时在日历上标注"数据不足"

### 7.3 网站结构变化风险

**问题**：如果网站改版，HTML 结构变化可能导致抓取失败。

**处理方案**：
- 抓取模块集中封装，便于修改
- 抓取失败时返回明确的错误信息
- 在日志中记录失败原因

### 7.4 反爬与访问频率

**问题**：频繁请求可能被网站封禁。

**处理方案**：
- 控制采集频率（每小时 1-2 次足够）
- 设置合理的 User-Agent
- 请求失败时指数退避重试

## 八、部署与使用

### 本地运行
```bash
npm install
npm start
# 访问 http://localhost:3000
```

### 配置
- 电表号在 `.env` 或 `config.js` 中配置
- 可配置采集间隔时间

## 九、扩展方向（可选）

1. **多电表支持**：管理多个电表的数据
2. **告警通知**：电量低于阈值时发送提醒（邮件/微信）
3. **数据导出**：导出 Excel/CSV 报表
4. **月度统计**：按月汇总用电量和电费
5. **用电预测**：基于历史数据预测未来用电量
