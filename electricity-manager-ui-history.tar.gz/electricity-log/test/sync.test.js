process.env.DB_PATH=':memory:';process.env.METER_ID='test';
const assert=require('assert');const express=require('express');const db=require('../server/db');db.initDB();
const c=require('../server/cnyiot');let authenticated=false;c.getAuthStatus=()=>({authenticated});
c.getDailyUsage=async()=>[{date:'2026-08-01',usageKwh:6.56},{date:'2026-08-02',usageKwh:null}];
c.getHourlyUsage=async()=>[{hour:1,usageKwh:.5},{hour:2,usageKwh:null}];
const app=express();app.use(express.json());app.use('/api/sync',require('../server/routes/sync'));
const server=app.listen(0,async()=>{const post=body=>fetch(`http://127.0.0.1:${server.address().port}/api/sync`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});try{
assert.equal((await post({date:'bad',scope:'month'})).status,400);
assert.equal((await post({date:'2026-08-01',scope:'month'})).status,401);
authenticated=true;let r=await(await post({date:'2026-08-01',scope:'month'})).json();assert.equal(r.data.count,1);assert.equal(db.getDailyUsageByMonth('test',2026,8)[0].usage_kwh,6.56);
r=await(await post({date:'2026-08-01',scope:'day'})).json();assert.equal(r.data.count,1);
c.getDailyUsage=async()=>{throw Error('offline')};assert.equal((await post({date:'2026-08-01',scope:'month'})).status,502);assert.equal(db.getDailyUsageByMonth('test',2026,8)[0].usage_kwh,6.56);
console.log('PASS: validation, auth, month/day sync, null filtering, offline cache preservation');
}catch(e){console.error(e);process.exitCode=1;}finally{server.close();db.getDB().close();}});
