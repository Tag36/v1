document.addEventListener('DOMContentLoaded',()=>{
 $('monthPicker').max=localDate().slice(0,7);
 $('monthPicker').value=`${calendar.year}-${String(calendar.month).padStart(2,'0')}`;
 $('monthPicker').onchange=e=>{if(!e.target.value)return;const[y,m]=e.target.value.split('-').map(Number);calendar.year=y;calendar.month=m;calendar.setUsageData([]);loadMonth(y,m)};
 $('syncMonth').onclick=()=>syncHistory('month',$('syncMonth'));
 $('syncDay').onclick=()=>syncHistory('day',$('syncDay'));
 $('yesterday').onclick=()=>{hourDate=localDate(new Date(Date.now()-86400000));$('hourlyDate').value=hourDate;loadHourly()};
 const media=matchMedia('(prefers-color-scheme: dark)');
 const theme=()=>{document.querySelector('meta[name="theme-color"]').content=media.matches?'#07101d':'#f6f8fb';if(typeof Chart==='undefined')return;Chart.defaults.color=media.matches?'#a1b2c7':'#64748b';for(const obj of [usageChart,hourlyChart]){if(!obj?.chart)continue;const c=obj.chart;c.options.plugins.legend.labels.color=Chart.defaults.color;for(const axis of Object.values(c.options.scales)){axis.ticks.color=Chart.defaults.color;}c.update()}};
 media.addEventListener('change',theme);theme();
});
async function syncHistory(scope,button){
 const date=scope==='month'?`${calendar.year}-${String(calendar.month).padStart(2,'0')}-01`:hourDate;
 const label=button.textContent;button.disabled=true;button.textContent='同步中…';
 try{const r=await get('/api/sync',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({scope,date})});toast(r.message);await loadAll()}catch(e){toast(e.message)}finally{button.disabled=false;button.textContent=label;loadStatus()}
}
