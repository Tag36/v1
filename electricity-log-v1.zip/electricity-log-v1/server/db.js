const Database = require('better-sqlite3');
const fs = require('fs');
const path = require('path');
const { todayShanghai } = require('./time');

const DATA_DIR = path.join(__dirname, '..', 'data');
const DB_PATH = path.join(DATA_DIR, 'electricity.db');

let db;

function initDB() {
  fs.mkdirSync(DATA_DIR, { recursive: true });

  db = new Database(DB_PATH);
  db.pragma('journal_mode = WAL');
  db.pragma('foreign_keys = ON');

  db.exec(`
    CREATE TABLE IF NOT EXISTS meter_readings (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      meter_id TEXT NOT NULL,
      meter_name TEXT,
      remaining_kwh REAL NOT NULL DEFAULT 0,
      remaining_money REAL NOT NULL DEFAULT 0,
      price_per_kwh REAL NOT NULL DEFAULT 0,
      total_kwh REAL,
      voltage REAL,
      current_amp REAL,
      power_factor REAL,
      power_kw REAL,
      relay_status INTEGER,
      source TEXT NOT NULL DEFAULT 'public-pay',
      device_time TEXT,
      collected_at TEXT NOT NULL
    );

    CREATE INDEX IF NOT EXISTS idx_meter_readings_meter_id
      ON meter_readings(meter_id);
    CREATE INDEX IF NOT EXISTS idx_meter_readings_collected_at
      ON meter_readings(collected_at);

    CREATE TABLE IF NOT EXISTS daily_usage (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      meter_id TEXT NOT NULL,
      date TEXT NOT NULL,
      start_kwh REAL,
      end_kwh REAL,
      usage_kwh REAL DEFAULT 0,
      cost_money REAL DEFAULT 0,
      is_recharge INTEGER DEFAULT 0,
      source TEXT NOT NULL DEFAULT 'calculated-remaining',
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      UNIQUE(meter_id, date)
    );

    CREATE INDEX IF NOT EXISTS idx_daily_usage_meter_id
      ON daily_usage(meter_id);
    CREATE INDEX IF NOT EXISTS idx_daily_usage_date
      ON daily_usage(date);

    CREATE TABLE IF NOT EXISTS hourly_usage (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      meter_id TEXT NOT NULL,
      date TEXT NOT NULL,
      hour INTEGER NOT NULL,
      usage_kwh REAL,
      cost_money REAL,
      is_recharge INTEGER DEFAULT 0,
      source TEXT NOT NULL DEFAULT 'cnyiot-official',
      updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      UNIQUE(meter_id, date, hour)
    );

    CREATE INDEX IF NOT EXISTS idx_hourly_usage_date
      ON hourly_usage(meter_id, date);

    CREATE TABLE IF NOT EXISTS monthly_usage (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      meter_id TEXT NOT NULL,
      year INTEGER NOT NULL,
      month INTEGER NOT NULL,
      usage_kwh REAL,
      cost_money REAL,
      source TEXT NOT NULL DEFAULT 'cnyiot-official',
      updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      UNIQUE(meter_id, year, month)
    );
  `);

  return db;
}

function getDB() {
  if (!db) initDB();
  return db;
}

function insertReading(data) {
  const stmt = getDB().prepare(`
    INSERT INTO meter_readings (
      meter_id, meter_name, remaining_kwh, remaining_money, price_per_kwh,
      total_kwh, voltage, current_amp, power_factor, power_kw, relay_status,
      source, device_time, collected_at
    ) VALUES (
      @meterId, @meterName, @remainingKwh, @remainingMoney, @pricePerKwh,
      @totalKwh, @voltage, @currentAmp, @powerFactor, @powerKw, @relayStatus,
      @source, @deviceTime, @collectedAt
    )
  `);

  const row = {
    meterId: String(data.meterId),
    meterName: data.meterName || '未知',
    remainingKwh: Number(data.remainingKwh) || 0,
    remainingMoney: Number(data.remainingMoney) || 0,
    pricePerKwh: Number(data.pricePerKwh) || 0,
    totalKwh: nullableNumber(data.totalKwh),
    voltage: nullableNumber(data.voltage),
    currentAmp: nullableNumber(data.currentAmp),
    powerFactor: nullableNumber(data.powerFactor),
    powerKw: nullableNumber(data.powerKw),
    relayStatus: data.relayStatus === null || data.relayStatus === undefined
      ? null
      : Number(data.relayStatus),
    source: data.source || 'public-pay',
    deviceTime: data.deviceTime || null,
    collectedAt: data.collectedAt,
  };

  return stmt.run(row).lastInsertRowid;
}

function nullableNumber(value) {
  if (value === null || value === undefined || value === '') return null;
  const n = Number(value);
  return Number.isFinite(n) ? n : null;
}

function getLatestReading(meterId) {
  return getDB().prepare(`
    SELECT *
    FROM meter_readings
    WHERE meter_id = ?
    ORDER BY collected_at DESC
    LIMIT 1
  `).get(String(meterId));
}

function getReadingsByDateRange(meterId, startDate, endDate) {
  return getDB().prepare(`
    SELECT *
    FROM meter_readings
    WHERE meter_id = ?
      AND DATE(collected_at, '+8 hours') BETWEEN ? AND ?
    ORDER BY collected_at ASC
  `).all(String(meterId), startDate, endDate);
}

function getFirstReadingOfDay(meterId, date) {
  return getDB().prepare(`
    SELECT *
    FROM meter_readings
    WHERE meter_id = ?
      AND DATE(collected_at, '+8 hours') = ?
    ORDER BY collected_at ASC
    LIMIT 1
  `).get(String(meterId), date);
}

function getLastReadingOfDay(meterId, date) {
  return getDB().prepare(`
    SELECT *
    FROM meter_readings
    WHERE meter_id = ?
      AND DATE(collected_at, '+8 hours') = ?
    ORDER BY collected_at DESC
    LIMIT 1
  `).get(String(meterId), date);
}

function getLastReadingBeforeDate(meterId, date) {
  return getDB().prepare(`
    SELECT *
    FROM meter_readings
    WHERE meter_id = ?
      AND DATE(collected_at, '+8 hours') < ?
    ORDER BY collected_at DESC
    LIMIT 1
  `).get(String(meterId), date);
}

function upsertDailyUsage(data) {
  const existing = getDB().prepare(`
    SELECT source
    FROM daily_usage
    WHERE meter_id = ? AND date = ?
  `).get(String(data.meterId), data.date);

  // 官方数据优先。已有官方记录时，计算兜底不得覆盖。
  if (
    existing &&
    existing.source === 'cnyiot-official' &&
    data.source !== 'cnyiot-official'
  ) {
    return { changes: 0 };
  }

  return getDB().prepare(`
    INSERT INTO daily_usage (
      meter_id, date, start_kwh, end_kwh, usage_kwh,
      cost_money, is_recharge, source, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
    ON CONFLICT(meter_id, date) DO UPDATE SET
      start_kwh = excluded.start_kwh,
      end_kwh = excluded.end_kwh,
      usage_kwh = excluded.usage_kwh,
      cost_money = excluded.cost_money,
      is_recharge = excluded.is_recharge,
      source = excluded.source,
      updated_at = CURRENT_TIMESTAMP
  `).run(
    String(data.meterId),
    data.date,
    nullableNumber(data.startKwh),
    nullableNumber(data.endKwh),
    Number(data.usageKwh) || 0,
    Number(data.costMoney) || 0,
    data.isRecharge ? 1 : 0,
    data.source || 'calculated-remaining'
  );
}

function upsertHourlyUsage(data) {
  return getDB().prepare(`
    INSERT INTO hourly_usage (
      meter_id, date, hour, usage_kwh, cost_money,
      is_recharge, source, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
    ON CONFLICT(meter_id, date, hour) DO UPDATE SET
      usage_kwh = excluded.usage_kwh,
      cost_money = excluded.cost_money,
      is_recharge = excluded.is_recharge,
      source = excluded.source,
      updated_at = CURRENT_TIMESTAMP
  `).run(
    String(data.meterId),
    data.date,
    Number(data.hour),
    nullableNumber(data.usageKwh),
    nullableNumber(data.costMoney),
    data.isRecharge ? 1 : 0,
    data.source || 'cnyiot-official'
  );
}

function upsertMonthlyUsage(data) {
  return getDB().prepare(`
    INSERT INTO monthly_usage (
      meter_id, year, month, usage_kwh, cost_money, source, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
    ON CONFLICT(meter_id, year, month) DO UPDATE SET
      usage_kwh = excluded.usage_kwh,
      cost_money = excluded.cost_money,
      source = excluded.source,
      updated_at = CURRENT_TIMESTAMP
  `).run(
    String(data.meterId),
    Number(data.year),
    Number(data.month),
    nullableNumber(data.usageKwh),
    nullableNumber(data.costMoney),
    data.source || 'cnyiot-official'
  );
}

function getDailyUsageByDateRange(meterId, startDate, endDate) {
  return getDB().prepare(`
    SELECT *
    FROM daily_usage
    WHERE meter_id = ? AND date BETWEEN ? AND ?
    ORDER BY date ASC
  `).all(String(meterId), startDate, endDate);
}

function getDailyUsageByMonth(meterId, year, month) {
  const startDate = `${year}-${String(month).padStart(2, '0')}-01`;
  const endDate = `${year}-${String(month).padStart(2, '0')}-31`;
  return getDailyUsageByDateRange(meterId, startDate, endDate);
}

function getRecentDailyUsage(meterId, days) {
  return getDB().prepare(`
    SELECT *
    FROM daily_usage
    WHERE meter_id = ?
      AND date >= DATE('now', '+8 hours', ?)
    ORDER BY date ASC
  `).all(String(meterId), `-${Number(days)} days`);
}

function getOfficialHourlyUsage(meterId, date) {
  return getDB().prepare(`
    SELECT *
    FROM hourly_usage
    WHERE meter_id = ? AND date = ?
    ORDER BY hour ASC
  `).all(String(meterId), date);
}

function getFallbackHourlyUsage(meterId, date) {
  const rows = getDB().prepare(`
    SELECT
      CAST(strftime('%H', collected_at, '+8 hours') AS INTEGER) AS hour,
      remaining_kwh,
      remaining_money,
      price_per_kwh,
      collected_at
    FROM meter_readings
    WHERE meter_id = ?
      AND DATE(collected_at, '+8 hours') = ?
    ORDER BY collected_at ASC
  `).all(String(meterId), date);

  const out = [];

  for (let h = 0; h < 24; h++) {
    const records = rows.filter(r => r.hour === h);
    if (!records.length) {
      out.push({
        hour: h,
        usage_kwh: null,
        cost_money: null,
        is_recharge: 0,
        source: 'calculated-remaining',
      });
      continue;
    }

    const startKwh = Number(records[0].remaining_kwh);
    const endKwh = Number(records[records.length - 1].remaining_kwh);
    let usage = startKwh - endKwh;
    const isRecharge = usage < 0;
    if (isRecharge) usage = 0;

    const price = Number(records[records.length - 1].price_per_kwh) || 0;
    out.push({
      hour: h,
      usage_kwh: Math.round(usage * 1000) / 1000,
      cost_money: Math.round(usage * price * 100) / 100,
      is_recharge: isRecharge ? 1 : 0,
      source: 'calculated-remaining',
      start_kwh: startKwh,
      end_kwh: endKwh,
    });
  }

  return out;
}

function getHourlyUsage(meterId, date) {
  const official = getOfficialHourlyUsage(meterId, date);
  const officialMap = new Map(official.map(r => [Number(r.hour), r]));

  if (official.length) {
    return Array.from({ length: 24 }, (_, hour) => {
      const r = officialMap.get(hour);
      return r || {
        hour,
        usage_kwh: null,
        cost_money: null,
        is_recharge: 0,
        source: 'cnyiot-official',
      };
    });
  }

  return getFallbackHourlyUsage(meterId, date);
}

function getMonthlyUsage(meterId, year, month) {
  return getDB().prepare(`
    SELECT *
    FROM monthly_usage
    WHERE meter_id = ? AND year = ? AND month = ?
  `).get(String(meterId), Number(year), Number(month));
}

function calculateAndUpdateDailyUsage(meterId, date) {
  const dayEnd = getLastReadingOfDay(meterId, date);
  if (!dayEnd) return null;

  const dayStart = getLastReadingBeforeDate(meterId, date) || getFirstReadingOfDay(meterId, date);
  if (!dayStart) return null;

  const startKwh = Number(dayStart.remaining_kwh);
  const endKwh = Number(dayEnd.remaining_kwh);
  let usageKwh = startKwh - endKwh;
  let isRecharge = false;

  if (usageKwh < 0) {
    isRecharge = true;
    usageKwh = 0;
  }

  usageKwh = Math.round(usageKwh * 100) / 100;
  const price = Number(dayEnd.price_per_kwh) || 0;
  const costMoney = Math.round(usageKwh * price * 100) / 100;

  upsertDailyUsage({
    meterId,
    date,
    startKwh,
    endKwh,
    usageKwh,
    costMoney,
    isRecharge,
    source: 'calculated-remaining',
  });

  return { meterId, date, startKwh, endKwh, usageKwh, costMoney, isRecharge };
}

function getMonthSummary(meterId, year, month) {
  const monthly = getMonthlyUsage(meterId, year, month);
  const daily = getDailyUsageByMonth(meterId, year, month).filter(r => r.usage_kwh !== null);

  let totalUsage = monthly?.usage_kwh ?? null;
  let totalCost = monthly?.cost_money ?? null;

  // 月累计优先使用辰域官方月数据。
  // 若官方月数据尚未同步，则保持 null，不在这里猜测成“官方值”。
  const daysWithData = daily.filter(r => Number.isFinite(Number(r.usage_kwh))).length;
  const avgDailyUsage = totalUsage !== null && daysWithData
    ? Number(totalUsage) / daysWithData
    : null;
  const avgDailyCost = totalCost !== null && daysWithData
    ? Number(totalCost) / daysWithData
    : null;

  const today = todayShanghai();
  const todayRow = daily.find(r => r.date === today) || null;
  const yesterday = daily.find(r => {
    const d = new Date(`${today}T00:00:00+08:00`);
    d.setDate(d.getDate() - 1);
    const y = new Intl.DateTimeFormat('en-CA', {
      timeZone: 'Asia/Shanghai', year: 'numeric', month: '2-digit', day: '2-digit'
    }).format(d);
    return r.date === y;
  }) || null;

  let todayVsYesterdayPercent = null;
  if (todayRow && yesterday && Number(yesterday.usage_kwh) > 0) {
    todayVsYesterdayPercent =
      ((Number(todayRow.usage_kwh) - Number(yesterday.usage_kwh)) / Number(yesterday.usage_kwh)) * 100;
  }

  return {
    totalUsage,
    totalCost,
    avgDailyUsage,
    avgDailyCost,
    daysWithData,
    todayVsYesterdayPercent,
    source: monthly?.source || null,
  };
}

module.exports = {
  initDB,
  getDB,
  insertReading,
  getLatestReading,
  getReadingsByDateRange,
  upsertDailyUsage,
  upsertHourlyUsage,
  upsertMonthlyUsage,
  getDailyUsageByDateRange,
  getDailyUsageByMonth,
  getRecentDailyUsage,
  getHourlyUsage,
  getMonthlyUsage,
  getMonthSummary,
  calculateAndUpdateDailyUsage,
};
