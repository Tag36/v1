const axios = require('axios');
const cheerio = require('cheerio');
const { nowUTCISO } = require('./time');

const PUBLIC_PAY_URL =
  process.env.PUBLIC_PAY_URL || 'https://www.wap.cnyiot.com/nat/pay.aspx';

const USER_AGENT =
  'Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) ' +
  'AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Mobile/15E148 Safari/604.1';

async function fetchPublicMeterData(meterId) {
  const response = await axios.get(PUBLIC_PAY_URL, {
    params: { mid: meterId },
    timeout: 15000,
    headers: {
      'User-Agent': USER_AGENT,
      'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
      'Accept-Language': 'zh-CN,zh-Hans;q=0.9',
    },
  });

  const $ = cheerio.load(response.data);

  const meterName = $('label').eq(0).text().trim() || '未知';
  const meterIdFromPage = $('#metid').text().trim() || String(meterId);

  let remainingKwh = 0;
  let remainingMoney = 0;
  let pricePerKwh = 0;

  $('label').each((_, el) => {
    const text = $(el).text().trim();
    const parentText = $(el).parent().text().trim();

    if (parentText.includes('剩余电量')) {
      remainingKwh = Number.parseFloat(text) || 0;
    } else if (parentText.includes('剩余金额')) {
      remainingMoney = Number.parseFloat(text) || 0;
    } else if (parentText.includes('综合费用')) {
      pricePerKwh = Number.parseFloat(text) || 0;
    }
  });

  return {
    meterId: meterIdFromPage,
    meterName,
    remainingKwh,
    remainingMoney,
    pricePerKwh,
    source: 'public-pay',
    collectedAt: nowUTCISO(),
  };
}

module.exports = {
  fetchPublicMeterData,
};
