(() => {
  "use strict";

  const TZ = "Asia/Shanghai";
  const $ = (id) => document.getElementById(id);

  const state = {
    current: null,
    currentMonth: null,
    calendarRecords: [],
    trendDays: 7,
    hourlyDate: null,
    toastTimer: null
  };

  // Display-only field accessors. API payloads are never rewritten or posted back.
  function read(obj, names, fallback = null) {
    if (!obj) return fallback;
    for (const name of names) {
      if (obj[name] !== undefined && obj[name] !== null) return obj[name];
    }
    return fallback;
  }

  function unwrap(payload) {
    if (payload && payload.data !== undefined) return payload.data;
    return payload;
  }

  function recordsOf(payload) {
    const data = unwrap(payload);
    if (Array.isArray(data)) return data;
    const records = read(data, ["records", "items", "list", "daily", "hourly"], []);
    return Array.isArray(records) ? records : [];
  }

  async function api(url, options = {}) {
    const res = await fetch(url, {
      cache: "no-store",
      headers: { "Accept": "application/json", ...(options.headers || {}) },
      ...options
    });
    if (!res.ok) throw new Error(`${res.status} ${res.statusText}`);
    return res.json();
  }

  function formatNumber(value, digits = 2) {
    const n = Number(value);
    return Number.isFinite(n) ? n.toFixed(digits) : "--";
  }

  function formatMoney(value) {
    const n = Number(value);
    return Number.isFinite(n) ? `¥${n.toFixed(2)}` : "--";
  }

  function formatPrice(value) {
    const n = Number(value);
    return Number.isFinite(n) ? `${n.toFixed(2)} 元/kWh` : "--";
  }

  function shanghaiParts(date = new Date()) {
    const parts = new Intl.DateTimeFormat("zh-CN", {
      timeZone: TZ,
      year: "numeric",
      month: "2-digit",
      day: "2-digit"
    }).formatToParts(date);
    const out = {};
    for (const p of parts) if (p.type !== "literal") out[p.type] = p.value;
    return {
      year: Number(out.year),
      month: Number(out.month),
      day: Number(out.day)
    };
  }

  function shanghaiDateKey(date = new Date()) {
    const p = shanghaiParts(date);
    return `${p.year}-${String(p.month).padStart(2, "0")}-${String(p.day).padStart(2, "0")}`;
  }

  function shanghaiDateTime(value) {
    if (!value) return "--";
    const d = value instanceof Date ? value : new Date(value);
    if (Number.isNaN(d.getTime())) {
      // Keep backend-provided local-looking strings intact instead of forcing UTC parsing.
      return String(value).replace("T", " ").replace(/\.\d{3}Z$/, "");
    }
    return new Intl.DateTimeFormat("zh-CN", {
      timeZone: TZ,
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
      hour12: false
    }).format(d).replace(/\//g, "-");
  }

  function shanghaiWeekday(dateString) {
    if (!dateString) return "";
    const d = new Date(`${String(dateString).slice(0, 10)}T12:00:00+08:00`);
    return new Intl.DateTimeFormat("zh-CN", {
      timeZone: TZ,
      weekday: "long"
    }).format(d);
  }

  function animateValue(el) {
    if (!el) return;
    el.classList.remove("number-pop");
    void el.offsetWidth;
    el.classList.add("number-pop");
  }

  function setStatus(kind, text) {
    const dot = $("currentStatusDot");
    dot.classList.remove("is-success", "is-error");
    if (kind === "success") dot.classList.add("is-success");
    if (kind === "error") dot.classList.add("is-error");
    $("lastUpdated").textContent = text;
  }

  function setModuleState(id, kind, text) {
    const el = $(id);
    if (!el) return;
    el.className = `module-state is-${kind}`;
    if (kind === "ready") {
      el.innerHTML = "";
      return;
    }
    const icon = kind === "loading"
      ? '<span class="state-spinner"></span>'
      : `<svg style="width:17px;height:17px"><use href="#${kind === "error" ? "i-error" : "i-info"}"></use></svg>`;
    el.innerHTML = `${icon}<span>${text}</span>`;
  }

  function showToast(type, title, message = "") {
    const toast = $("toast");
    const icon = type === "success" ? "i-check" : "i-error";
    toast.className = `toast is-${type}`;
    $("toastIcon").innerHTML = `<svg><use href="#${icon}"></use></svg>`;
    $("toastTitle").textContent = title;
    $("toastMessage").textContent = message;
    clearTimeout(state.toastTimer);
    requestAnimationFrame(() => toast.classList.add("is-visible"));
    state.toastTimer = setTimeout(() => toast.classList.remove("is-visible"), 1800);
  }

  function setRefreshing(on) {
    const btn = $("refreshBtn");
    btn.classList.toggle("is-loading", on);
    btn.disabled = on;
    btn.setAttribute("aria-busy", String(on));
  }

  function renderCurrent(payload) {
    const data = unwrap(payload) || {};

    // These preserve the project's existing snake_case fields first.
    const remainingKwh = read(data, ["remaining_kwh", "remainingKwh", "ekwh"]);
    const remainingMoney = read(data, ["remaining_money", "remainingMoney", "balance"]);
    const price = read(data, ["price_per_kwh", "pricePerKwh", "price", "mpce"]);
    const meterId = read(data, ["meter_id", "meterId", "meter_no", "meterNo"], "--");
    const meterName = read(data, ["meter_name", "meterName", "name"], "--");
    const collectedAt = read(data, ["collected_at", "collectedAt", "updated_at", "datetime", "d"]);

    $("remainingKwh").textContent = formatNumber(remainingKwh);
    $("remainingMoney").textContent = formatMoney(remainingMoney);
    $("pricePerKwh").textContent = formatPrice(price);
    $("meterName").textContent = String(meterName ?? "--");
    $("meterId").textContent = String(meterId ?? "--");
    $("meterPrice").textContent = formatPrice(price);
    $("meterCollectedAt").textContent = shanghaiDateTime(collectedAt);

    animateValue($("remainingKwh"));

    const timeText = collectedAt ? `最后更新 ${shanghaiDateTime(collectedAt)}` : "数据加载完成";
    setStatus("success", timeText);
    state.current = data;
  }

  async function loadCurrent() {
    try {
      const payload = await api("/api/meter/current");
      renderCurrent(payload);
      return true;
    } catch (err) {
      console.error("current meter load failed", err);
      setStatus("error", "当前电量加载失败");
      return false;
    }
  }

  function monthQuery(year, month) {
    return `/api/records/month?year=${encodeURIComponent(year)}&month=${encodeURIComponent(month)}`;
  }

  function renderTodayFromMonth(payload, dateKey) {
    const data = unwrap(payload) || {};
    const records = recordsOf(payload);
    const today = records.find(r => String(read(r, ["date"], "")).slice(0, 10) === dateKey);

    const usage = today ? read(today, ["usage_kwh", "usageKwh", "usage"]) : read(data, ["today_usage_kwh", "today_usage"]);
    const cost = today ? read(today, ["costMoney", "cost", "cost_yuan", "fee"]) : read(data, ["today_cost", "today_fee"]);

    $("todayUsage").textContent = formatNumber(usage);
    $("todayCost").textContent = formatNumber(cost);

    const trend = read(payload?.summary || {}, ["todayVsYesterdayPercent"]);
    const trendEl = $("todayTrend");
    if (Number.isFinite(Number(trend))) {
      const n = Number(trend);
      const icon = n > 0 ? "i-up" : n < 0 ? "i-down" : "i-info";
      const cls = n > 0 ? "is-up" : n < 0 ? "is-down" : "is-flat";
      trendEl.className = `trend-chip ${cls}`;
      trendEl.innerHTML = `<span>较昨日</span><svg><use href="#${icon}"></use></svg><span>${Math.abs(n).toFixed(1)}%</span>`;
    } else {
      trendEl.className = "trend-chip is-hidden";
      trendEl.textContent = "";
    }
  }

  function renderMonthSummary(payload) {
    const data = payload?.summary || {};

    // Monthly totals come from the backend summary. The frontend never sums days.
    const monthUsage = read(data, ["totalUsage"]);
    const monthCost = read(data, ["totalCost"]);
    const avgUsage = read(data, ["avgDailyUsage"]);
    const avgCost = read(data, ["avgDailyCost"]);

    $("monthUsage").textContent = formatNumber(monthUsage);
    $("monthCost").textContent = formatNumber(monthCost);
    $("monthAvgUsage").textContent = Number.isFinite(Number(avgUsage))
      ? `${Number(avgUsage).toFixed(2)} kWh`
      : "--";
    $("monthAvgCost").textContent = Number.isFinite(Number(avgCost))
      ? `¥${Number(avgCost).toFixed(2)}`
      : "--";
  }

  async function loadMonth(year, month) {
    try {
      const payload = await api(monthQuery(year, month));
      const records = recordsOf(payload);
      state.calendarRecords = records;

      $("calendarMonthLabel").textContent = `${year}年${month}月`;
      window.EnergyCalendar?.render({
        container: $("calendarGrid"),
        year,
        month,
        records,
        onSelect: openDaySheet
      });

      const now = shanghaiParts();
      if (now.year === year && now.month === month) {
        renderTodayFromMonth(payload, shanghaiDateKey());
        renderMonthSummary(payload);
      }
      return true;
    } catch (err) {
      console.error("month load failed", err);
      $("calendarGrid").innerHTML =
        '<div class="module-state is-error" style="grid-column:1/-1"><svg style="width:17px;height:17px"><use href="#i-error"></use></svg><span>日历数据加载失败</span></div>';
      return false;
    }
  }

  function trendRecordValue(record) {
    return Number(read(record, ["usage_kwh", "usageKwh", "usage"]));
  }

  async function loadTrend(days = state.trendDays) {
    state.trendDays = days;
    setModuleState("trendChartState", "loading", "正在加载趋势数据");
    try {
      const payload = await api(`/api/records/recent?days=${encodeURIComponent(days)}`);
      const records = recordsOf(payload);

      if (!records.length) {
        setModuleState("trendChartState", "empty", "暂无趋势数据");
        return;
      }

      const labels = records.map(r => {
        const d = String(read(r, ["date"], ""));
        return d.length >= 10 ? `${Number(d.slice(5, 7))}/${Number(d.slice(8, 10))}` : d;
      });
      const values = records.map(r => {
        const n = trendRecordValue(r);
        return Number.isFinite(n) ? n : null;
      });

      setModuleState("trendChartState", "ready", "");
      window.EnergyCharts?.renderTrend($("trendChart"), labels, values);
    } catch (err) {
      console.error("trend load failed", err);
      setModuleState("trendChartState", "error", "趋势数据加载失败");
    }
  }

  function normalizeHourlyRecords(payload) {
    const records = recordsOf(payload);
    const values = Array(24).fill(null);
    const rechargeHours = [];

    for (const record of records) {
      const hourRaw = read(record, ["hour", "hour_of_day", "h"]);
      const timeRaw = read(record, ["time", "datetime", "collected_at"]);
      let hour = Number(hourRaw);

      if (!Number.isInteger(hour) && timeRaw) {
        const match = String(timeRaw).match(/(?:T|\s)(\d{1,2}):/);
        if (match) hour = Number(match[1]);
      }

      if (!Number.isInteger(hour) || hour < 0 || hour > 23) continue;

      const usage = Number(read(record, ["usage_kwh", "usageKwh", "usage"]));
      values[hour] = Number.isFinite(usage) ? usage : null;
      if (read(record, ["is_recharge", "isRecharge"], false)) rechargeHours.push(hour);
    }

    return { values, rechargeHours };
  }

  function renderHourlySummary(payload) {
    const data = payload?.summary || {};
    // Display backend summary fields only; do not sum chart bars here.
    const totalUsage = read(data, ["totalUsage"]);
    const totalCost = read(data, ["totalCost"]);
    const period = read(data, ["collectionPeriod"]);

    $("hourlyTotalUsage").textContent = formatNumber(totalUsage);
    $("hourlyTotalCost").textContent = formatNumber(totalCost);
    $("hourlyPeriod").textContent = period ? String(period) : "--";
  }

  async function loadHourly(dateKey = state.hourlyDate) {
    state.hourlyDate = dateKey;
    $("hourlyDateButton").textContent = dateKey;
    $("hourlyDateInput").value = dateKey;

    const today = shanghaiDateKey();
    $("nextDayBtn").disabled = dateKey >= today;

    setModuleState("hourlyChartState", "loading", "正在加载小时数据");
    try {
      const payload = await api(`/api/records/hourly?date=${encodeURIComponent(dateKey)}`);
      const records = recordsOf(payload);
      renderHourlySummary(payload);

      if (!records.length) {
        setModuleState("hourlyChartState", "empty", "该日期暂无小时数据");
        return;
      }

      const { values, rechargeHours } = normalizeHourlyRecords(payload);
      if (!values.some(v => Number.isFinite(v))) {
        setModuleState("hourlyChartState", "empty", "该日期暂无可绘制的小时数据");
        return;
      }

      setModuleState("hourlyChartState", "ready", "");
      window.EnergyCharts?.renderHourly($("hourlyChart"), values, rechargeHours);
    } catch (err) {
      console.error("hourly load failed", err);
      setModuleState("hourlyChartState", "error", "小时数据加载失败");
    }
  }

  function openDaySheet(record) {
    const date = String(read(record, ["date"], "")).slice(0, 10);
    const startKwh = read(record, ["start_kwh", "startKwh"]);
    const endKwh = read(record, ["end_kwh", "endKwh"]);
    const usage = read(record, ["usage_kwh", "usageKwh", "usage"]);
    const cost = read(record, ["costMoney", "cost", "cost_yuan", "fee"]);
    const isRecharge = !!read(record, ["is_recharge", "isRecharge"], false);

    const [year, month, day] = date.split("-").map(Number);
    $("sheetTitle").textContent = year && month && day ? `${year}年${month}月${day}日` : date || "--";
    $("sheetWeekday").textContent = date ? shanghaiWeekday(date) : "--";
    $("sheetStartKwh").textContent = Number.isFinite(Number(startKwh)) ? `${Number(startKwh).toFixed(2)} kWh` : "--";
    $("sheetEndKwh").textContent = Number.isFinite(Number(endKwh)) ? `${Number(endKwh).toFixed(2)} kWh` : "--";
    $("sheetUsage").textContent = Number.isFinite(Number(usage)) ? `${Number(usage).toFixed(2)} kWh` : "--";
    $("sheetCost").textContent = Number.isFinite(Number(cost)) ? `¥${Number(cost).toFixed(2)}` : "--";
    $("sheetRechargeBadge").classList.toggle("is-hidden", !isRecharge);

    $("sheetBackdrop").classList.add("is-open");
    $("daySheet").classList.add("is-open");
    $("sheetBackdrop").setAttribute("aria-hidden", "false");
    $("daySheet").setAttribute("aria-hidden", "false");
    document.body.classList.add("sheet-open");
  }

  function closeDaySheet() {
    $("sheetBackdrop").classList.remove("is-open");
    $("daySheet").classList.remove("is-open");
    $("sheetBackdrop").setAttribute("aria-hidden", "true");
    $("daySheet").setAttribute("aria-hidden", "true");
    document.body.classList.remove("sheet-open");
  }

  function shiftMonth(delta) {
    let { year, month } = state.currentMonth;
    month += delta;
    if (month < 1) { month = 12; year--; }
    if (month > 12) { month = 1; year++; }
    state.currentMonth = { year, month };
    loadMonth(year, month);
  }

  function shiftDateKey(dateKey, deltaDays) {
    const [y, m, d] = dateKey.split("-").map(Number);
    const dt = new Date(Date.UTC(y, m - 1, d + deltaDays, 4, 0, 0));
    return new Intl.DateTimeFormat("en-CA", {
      timeZone: TZ,
      year: "numeric",
      month: "2-digit",
      day: "2-digit"
    }).format(dt);
  }

  async function refreshAll({ userInitiated = false } = {}) {
    setRefreshing(true);

    let fetchOk = true;
    if (userInitiated) {
      try {
        await api("/api/meter/fetch");
      } catch (err) {
        fetchOk = false;
        console.error("manual fetch failed", err);
      }
    }

    // Current card is awaited first so it becomes visible as early as possible.
    const currentOk = await loadCurrent();

    const p = shanghaiParts();
    const tasks = [
      loadMonth(state.currentMonth.year, state.currentMonth.month),
      loadTrend(state.trendDays),
      loadHourly(state.hourlyDate)
    ];
    const results = await Promise.allSettled(tasks);
    setRefreshing(false);

    if (userInitiated) {
      const moduleOk = results.some(r => r.status === "fulfilled" && r.value !== false);
      if (fetchOk && currentOk && moduleOk) {
        showToast("success", "数据已更新");
      } else {
        showToast("error", "数据更新失败", "请稍后重试");
      }
    }
  }


  async function loadAuthStatus() {
    try {
      const payload = await api("/api/auth/status");
      const auth = payload?.data || {};
      const text = $("systemStatusText");
      if (!text) return;

      if (auth.authenticated) {
        text.innerHTML = '辰域官方数据已连接。历史用电优先使用辰域官方接口。';
      } else {
        text.innerHTML = '辰域尚未登录，当前可使用公开充值页/本地数据。<a href="/auth.html" style="color:#1677FF;text-decoration:none;font-weight:650;margin-left:4px">连接辰域</a>';
      }
    } catch (_) {}
  }

  function bindEvents() {
    $("refreshBtn").addEventListener("click", () => refreshAll({ userInitiated: true }));
    $("prevMonthBtn").addEventListener("click", () => shiftMonth(-1));
    $("nextMonthBtn").addEventListener("click", () => shiftMonth(1));

    document.querySelectorAll(".segment").forEach(btn => {
      btn.addEventListener("click", () => {
        document.querySelectorAll(".segment").forEach(b => b.classList.remove("is-active"));
        btn.classList.add("is-active");
        loadTrend(Number(btn.dataset.days));
      });
    });

    $("prevDayBtn").addEventListener("click", () => loadHourly(shiftDateKey(state.hourlyDate, -1)));
    $("nextDayBtn").addEventListener("click", () => {
      const next = shiftDateKey(state.hourlyDate, 1);
      if (next <= shanghaiDateKey()) loadHourly(next);
    });

    $("hourlyDateButton").addEventListener("click", () => {
      const input = $("hourlyDateInput");
      if (typeof input.showPicker === "function") input.showPicker();
      else input.click();
    });

    $("hourlyDateInput").addEventListener("change", (e) => {
      if (e.target.value && e.target.value <= shanghaiDateKey()) loadHourly(e.target.value);
    });

    $("sheetBackdrop").addEventListener("click", closeDaySheet);
    $("sheetCloseBtn").addEventListener("click", closeDaySheet);

    document.addEventListener("keydown", e => {
      if (e.key === "Escape") closeDaySheet();
    });
  }

  function init() {
    const p = shanghaiParts();
    state.currentMonth = { year: p.year, month: p.month };
    state.hourlyDate = shanghaiDateKey();

    $("calendarMonthLabel").textContent = `${p.year}年${p.month}月`;
    $("hourlyDateButton").textContent = state.hourlyDate;

    bindEvents();

    // First paint: fetch the core current meter first; other modules load independently.
    loadCurrent();
    loadMonth(p.year, p.month);
    loadTrend(7);
    loadHourly(state.hourlyDate);
    loadAuthStatus();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init, { once: true });
  } else {
    init();
  }
})();
