(() => {
  "use strict";

  const COLORS = {
    blue: "#1677FF",
    blueFill: "rgba(22, 119, 255, 0.10)",
    grid: "rgba(137, 151, 170, 0.12)",
    text: "#7B8797",
    green: "#2FA56D",
    grayBar: "rgba(22, 119, 255, 0.18)"
  };

  let trendChart = null;
  let hourlyChart = null;

  function commonOptions() {
    return {
      responsive: true,
      maintainAspectRatio: false,
      animation: { duration: 260 },
      interaction: {
        intersect: false,
        mode: "index"
      },
      plugins: {
        legend: { display: false },
        tooltip: {
          displayColors: false,
          padding: 10,
          cornerRadius: 10,
          backgroundColor: "rgba(255,255,255,.98)",
          titleColor: "#111827",
          bodyColor: "#596577",
          borderColor: "#E7ECF2",
          borderWidth: 1,
          titleFont: { size: 12, weight: "700" },
          bodyFont: { size: 11, weight: "600" },
          caretPadding: 8,
          callbacks: {
            label(context) {
              const value = Number(context.raw);
              if (!Number.isFinite(value)) return "暂无数据";
              return `${value.toFixed(2)} kWh`;
            }
          }
        }
      }
    };
  }

  function renderTrend(canvas, labels, values) {
    if (!window.Chart || !canvas) return;
    if (trendChart) trendChart.destroy();

    const ctx = canvas.getContext("2d");
    const gradient = ctx.createLinearGradient(0, 0, 0, 210);
    gradient.addColorStop(0, "rgba(22,119,255,.17)");
    gradient.addColorStop(1, "rgba(22,119,255,.015)");

    trendChart = new Chart(ctx, {
      type: "line",
      data: {
        labels,
        datasets: [{
          data: values,
          borderColor: COLORS.blue,
          backgroundColor: gradient,
          borderWidth: 2,
          fill: true,
          tension: .35,
          pointRadius: 0,
          pointHoverRadius: 4,
          pointHoverBackgroundColor: "#FFFFFF",
          pointHoverBorderColor: COLORS.blue,
          pointHoverBorderWidth: 2,
          spanGaps: false
        }]
      },
      options: {
        ...commonOptions(),
        scales: {
          x: {
            grid: { display: false },
            border: { display: false },
            ticks: {
              color: COLORS.text,
              font: { size: 10 },
              maxRotation: 0,
              autoSkip: true,
              maxTicksLimit: 7
            }
          },
          y: {
            beginAtZero: true,
            border: { display: false },
            grid: { color: COLORS.grid, drawTicks: false },
            ticks: {
              color: COLORS.text,
              font: { size: 10 },
              padding: 8,
              maxTicksLimit: 5,
              callback(value) { return Number(value).toFixed(value >= 10 ? 0 : 1); }
            }
          }
        }
      }
    });
  }

  function renderHourly(canvas, values, rechargeHours = []) {
    if (!window.Chart || !canvas) return;
    if (hourlyChart) hourlyChart.destroy();

    const labels = Array.from({ length: 24 }, (_, i) => String(i).padStart(2, "0"));
    const recharge = new Set(rechargeHours.map(Number));

    hourlyChart = new Chart(canvas.getContext("2d"), {
      type: "bar",
      data: {
        labels,
        datasets: [{
          data: values,
          backgroundColor: labels.map((_, i) =>
            recharge.has(i) ? "rgba(47,165,109,.72)" : "rgba(22,119,255,.72)"
          ),
          hoverBackgroundColor: labels.map((_, i) =>
            recharge.has(i) ? COLORS.green : COLORS.blue
          ),
          borderRadius: 5,
          borderSkipped: false,
          maxBarThickness: 12
        }]
      },
      options: {
        ...commonOptions(),
        interaction: { intersect: true, mode: "nearest" },
        scales: {
          x: {
            grid: { display: false },
            border: { display: false },
            ticks: {
              color: COLORS.text,
              font: { size: 9 },
              maxRotation: 0,
              callback(value, index) {
                return index % 2 === 0 ? labels[index] : "";
              }
            }
          },
          y: {
            beginAtZero: true,
            border: { display: false },
            grid: { color: COLORS.grid, drawTicks: false },
            ticks: {
              color: COLORS.text,
              font: { size: 10 },
              padding: 8,
              maxTicksLimit: 5
            }
          }
        },
        plugins: {
          ...commonOptions().plugins,
          tooltip: {
            ...commonOptions().plugins.tooltip,
            callbacks: {
              title(items) {
                if (!items.length) return "";
                const hour = items[0].dataIndex;
                return `${String(hour).padStart(2, "0")}:00 - ${String((hour + 1) % 24).padStart(2, "0")}:00`;
              },
              label(context) {
                const value = Number(context.raw);
                if (!Number.isFinite(value)) return "暂无数据";
                return `${value.toFixed(3)} kWh`;
              }
            }
          }
        }
      }
    });
  }

  window.EnergyCharts = {
    renderTrend,
    renderHourly
  };
})();
