(() => {
  "use strict";

  const TIME_ZONE = "Asia/Shanghai";

  function dateParts(date = new Date()) {
    const parts = new Intl.DateTimeFormat("zh-CN", {
      timeZone: TIME_ZONE,
      year: "numeric",
      month: "2-digit",
      day: "2-digit"
    }).formatToParts(date);

    const out = {};
    for (const p of parts) {
      if (p.type !== "literal") out[p.type] = p.value;
    }
    return {
      year: Number(out.year),
      month: Number(out.month),
      day: Number(out.day)
    };
  }

  function dateKey(year, month, day) {
    return `${year}-${String(month).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
  }

  function usageClass(value, isRecharge) {
    if (isRecharge) return "is-charge";
    if (!Number.isFinite(value)) return "";
    if (value < 3) return "is-low";
    if (value < 8) return "is-mid";
    return "is-high";
  }

  function render({ container, year, month, records, onSelect }) {
    if (!container) return;

    const today = dateParts();
    const firstDay = new Date(year, month - 1, 1).getDay();
    const daysInMonth = new Date(year, month, 0).getDate();

    const map = new Map();
    for (const record of records || []) {
      if (!record || !record.date) continue;
      map.set(String(record.date).slice(0, 10), record);
    }

    const frag = document.createDocumentFragment();

    for (let i = 0; i < firstDay; i++) {
      const empty = document.createElement("div");
      empty.className = "calendar-day is-empty";
      empty.setAttribute("aria-hidden", "true");
      frag.appendChild(empty);
    }

    for (let day = 1; day <= daysInMonth; day++) {
      const key = dateKey(year, month, day);
      const record = map.get(key);
      const usage = record ? Number(record.usage_kwh) : NaN;
      const isRecharge = !!(record && record.is_recharge);

      const button = document.createElement("button");
      button.type = "button";
      button.className = `calendar-day ${usageClass(usage, isRecharge)}`.trim();

      if (today.year === year && today.month === month && today.day === day) {
        button.classList.add("is-today");
      }

      button.innerHTML = `
        <span class="calendar-day__number">${day}</span>
        <span class="calendar-day__usage">${Number.isFinite(usage) ? `${usage.toFixed(1)} kWh` : "—"}</span>
        ${isRecharge ? '<svg class="calendar-day__charge" aria-hidden="true"><use href="#i-charge"></use></svg>' : ""}
      `;

      button.setAttribute("aria-label",
        Number.isFinite(usage) ? `${month}月${day}日，用电 ${usage.toFixed(2)} 千瓦时` : `${month}月${day}日，暂无数据`
      );

      if (record) {
        button.addEventListener("click", () => onSelect && onSelect(record));
      } else {
        button.disabled = true;
      }

      frag.appendChild(button);
    }

    container.replaceChildren(frag);
  }

  window.EnergyCalendar = {
    render,
    dateParts,
    dateKey
  };
})();
