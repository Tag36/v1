# 家庭用电监控 V1

基于原 `electricity-log` 项目结构整理的初版，目标是：

- 保留原 API 路径和原有字段
- iPhone Safari / 添加到主屏幕后拥有 iOS App 风格
- 所有业务日期按 `Asia/Shanghai`
- 辰域官方数据优先，公开充值页和本地差值只做兜底
- 一个数据模块失败不影响整个页面

## 数据来源优先级

### 当前电表

1. 辰域 `ReadInstant`
2. 辰域 `listMet`
3. 公开充值页 `pay.aspx`

剩余金额目前优先使用公开充值页，因为抓包中辰域内部金额缩写字段语义并不完全明确，不直接猜测。

### 每小时用电

优先：

`POST /wap/charts.aspx?Method=getView`，`mYMD=1`

无官方数据时才使用本地读数差值。

### 每日用电

优先：

`POST /wap/charts.aspx?Method=getView`，`mYMD=2`

无官方数据时才使用剩余电量差值。

### 每月用电

使用：

`POST /wap/charts.aspx?Method=getView`，`mYMD=3`

前端的“本月累计”和“本月电费”读取后端 `/api/records/month` 的 `summary`，前端不自行累加日记录。

## 原 API

仍保留：

- `GET /api/meter/current`
- `GET /api/meter/fetch`
- `GET /api/records/daily?start=YYYY-MM-DD&end=YYYY-MM-DD`
- `GET /api/records/recent?days=7`
- `GET /api/records/month?year=2026&month=8`
- `GET /api/records/hourly?date=2026-08-26`
- `GET /api/status`

原字段如 `meterId`、`remainingKwh`、`usageKwh`、`costMoney`、`isRecharge` 均保留。

V1 只额外增加了部分增强字段和 `summary`。

## 辰域登录

V1 使用人工验证码，不做 OCR。

接口：

- `GET /api/auth/status`
- `GET /api/auth/captcha`
- `POST /api/auth/login`
- `POST /api/auth/logout`

浏览器可直接访问：

`/auth.html`

验证码和服务器 Cookie Session 绑定，必须使用同一个服务器进程完成“获取验证码 → 登录 → 官方 API 请求”。

## 安装

```bash
cp .env.example .env
nano .env
```

至少填写：

```env
METER_ID=你的电表号
CNYIOT_PASSWORD=你的辰域密码
```

然后：

```bash
npm install
npm start
```

访问：

```text
http://服务器IP:3000
```

辰域登录：

```text
http://服务器IP:3000/auth.html
```

## 时区

- Node 业务时区：`Asia/Shanghai`
- Cron：`Asia/Shanghai`
- SQLite 采集时间：UTC ISO
- SQLite 按日切分：`+8 hours`
- 浏览器显示：`Intl.DateTimeFormat(... timeZone: "Asia/Shanghai")`

项目内不使用：

```js
new Date().toISOString().split('T')[0]
```

来判断北京时间日期。

## 目录

```text
electricity-log-v1/
├── server/
│   ├── index.js
│   ├── time.js
│   ├── db.js
│   ├── scraper.js
│   ├── cnyiot.js
│   ├── service.js
│   ├── scheduler.js
│   └── routes/
│       ├── meter.js
│       ├── records.js
│       └── auth.js
├── public/
│   ├── index.html
│   ├── auth.html
│   ├── css/style.css
│   └── js/
│       ├── app.js
│       ├── calendar.js
│       └── chart.js
├── data/
├── .env.example
├── .gitignore
├── package.json
└── README.md
```

## V1 说明

这是可继续迭代的初版，下一阶段适合做：

- 根据服务器实测 JSON 进一步收紧字段映射
- Session 失效检测和主页面内登录提示
- 同步跨月历史数据
- PWA manifest / App icon / Service Worker
- 辰域更多实时字段
- PM2 / Docker 部署
